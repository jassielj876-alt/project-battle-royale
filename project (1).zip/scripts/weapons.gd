class_name Weapons
extends RefCounted
## Datos de todas las armas.
## scope: "" = sin mira, "dot" = punto rojo con zoom, "sniper" = mira telescópica.

const DEFS := {
	"pistol": {
		"name": "PISTOLA", "dmg": 24.0, "rate": 0.25, "mag": 12, "reserve": 48,
		"pellets": 1, "spread": 0.006, "auto": false,
		"zoom": 1.0, "scope": "", "reload": 1.0, "recoil": 0.05,
		"ads": Vector3(0.0, -0.13, -0.4),
	},
	"rifle": {
		"name": "RIFLE (MIRA x1.8)", "dmg": 22.0, "rate": 0.11, "mag": 30, "reserve": 120,
		"pellets": 1, "spread": 0.012, "auto": true,
		"zoom": 1.8, "scope": "dot", "reload": 1.5, "recoil": 0.07,
		"ads": Vector3(0.0, -0.12, -0.5),
	},
	"shotgun": {
		"name": "ESCOPETA", "dmg": 11.0, "rate": 0.85, "mag": 6, "reserve": 12,
		"pellets": 8, "spread": 0.055, "auto": false,
		"zoom": 1.0, "scope": "", "reload": 2.0, "recoil": 0.16,
		"ads": Vector3(0.0, -0.2, -0.5),
	},
	"sniper": {
		"name": "FRANCOTIRADOR (x4)", "dmg": 65.0, "rate": 1.25, "mag": 5, "reserve": 10,
		"pellets": 1, "spread": 0.0, "auto": false,
		"zoom": 4.0, "scope": "sniper", "reload": 2.2, "recoil": 0.2,
		"ads": Vector3(0.0, -0.2, -0.5),
	},
}
