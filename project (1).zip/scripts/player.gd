class_name Player
extends CharacterBody3D
## Jugador en primera persona con 4 armas (hitscan). El rifle tiene mira de
## punto rojo (x1.8) y el francotirador mira telescópica (x4).

signal stats_changed
signal hit_taken
signal hit_confirmed(killed: bool)
signal died
signal message_posted(text: String)

const SPEED := 8.0
const JUMP_V := 7.0
const GRAV := 20.0
const LOOK_SENS := 0.0045
const BASE_FOV := 78.0
const HOME := Vector3(0.28, -0.26, -0.55)

var controls: TouchControls
var health := 100.0
var alive := true
var kills := 0

var owned: Array[String] = ["rifle", "pistol"]
var cur := "rifle"
var ammo := {}      # id -> balas en el cargador
var reserve := {}   # id -> balas de reserva
var reloading := false
var scoped := false

var _head: Node3D
var _cam: Camera3D
var _holder: Node3D
var _models := {}
var _muzzles := {}
var _flashes := {}
var _pitch := 0.0
var _cd := 0.0
var _flash_t := 0.0
var _kick := 0.0
var _reload_offset := 0.0
var _reload_id := 0
var _tap_buf := 0.0
var _tween: Tween


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)

	_head = Node3D.new()
	_head.position.y = 1.6
	add_child(_head)

	_cam = Camera3D.new()
	_cam.fov = BASE_FOV
	_cam.near = 0.05
	_cam.far = 400.0
	_head.add_child(_cam)
	_cam.make_current()

	for id in Weapons.DEFS:
		var d: Dictionary = Weapons.DEFS[id]
		ammo[id] = int(d["mag"])
		reserve[id] = int(d["reserve"])

	_build_weapons()
	_equip(cur)


# ------------------------------------------------------------------ modelos

func _build_weapons() -> void:
	_holder = Node3D.new()
	_holder.position = HOME
	_cam.add_child(_holder)

	for id in Weapons.DEFS:
		var m := Node3D.new()
		m.visible = false
		_holder.add_child(m)

		var muzzle := Vector3.ZERO
		match id:
			"pistol":
				muzzle = _model_pistol(m)
			"rifle":
				muzzle = _model_rifle(m)
			"shotgun":
				muzzle = _model_shotgun(m)
			"sniper":
				muzzle = _model_sniper(m)

		var mk := Node3D.new()
		mk.position = muzzle
		m.add_child(mk)

		var sm := SphereMesh.new()
		sm.radius = 0.09
		sm.height = 0.18
		var fl := MeshInstance3D.new()
		fl.mesh = sm
		var fmat := StandardMaterial3D.new()
		fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		fmat.albedo_color = Color(1.0, 0.85, 0.3)
		fl.material_override = fmat
		fl.position = muzzle
		fl.visible = false
		m.add_child(fl)

		_models[id] = m
		_muzzles[id] = mk
		_flashes[id] = fl


func _model_pistol(m: Node3D) -> Vector3:
	Toon.box(m, Vector3(0.07, 0.09, 0.30), Vector3(0, 0.0, -0.12), Color("2f3542"), false)
	Toon.box(m, Vector3(0.075, 0.05, 0.30), Vector3(0, 0.06, -0.12), Color("ff8a1f"), false)
	Toon.box(m, Vector3(0.06, 0.17, 0.08), Vector3(0, -0.12, 0.0), Color("ffb347"), false)
	return Vector3(0, 0.02, -0.30)


func _model_rifle(m: Node3D) -> Vector3:
	Toon.box(m, Vector3(0.10, 0.14, 0.55), Vector3(0, 0, 0), Color("2f3542"), false)
	Toon.box(m, Vector3(0.07, 0.07, 0.35), Vector3(0, 0.02, -0.42), Color("ff8a1f"), false)
	Toon.box(m, Vector3(0.08, 0.22, 0.10), Vector3(0, -0.15, 0.05), Color("ffb347"), false)
	Toon.box(m, Vector3(0.07, 0.16, 0.08), Vector3(0, -0.12, 0.25), Color("2f3542"), false)
	# Mira de punto rojo (base + dos postes laterales; el centro queda libre)
	Toon.box(m, Vector3(0.06, 0.03, 0.10), Vector3(0, 0.085, -0.1), Color("1d1f26"), false)
	Toon.box(m, Vector3(0.012, 0.06, 0.03), Vector3(-0.026, 0.12, -0.1), Color("1d1f26"), false)
	Toon.box(m, Vector3(0.012, 0.06, 0.03), Vector3(0.026, 0.12, -0.1), Color("1d1f26"), false)
	return Vector3(0, 0.02, -0.65)


func _model_shotgun(m: Node3D) -> Vector3:
	Toon.box(m, Vector3(0.09, 0.12, 0.45), Vector3(0, 0, 0.05), Color("8a5a2b"), false)
	Toon.box(m, Vector3(0.05, 0.05, 0.70), Vector3(0, 0.03, -0.45), Color("9aa0aa"), false)
	Toon.box(m, Vector3(0.06, 0.06, 0.28), Vector3(0, -0.04, -0.35), Color("5a3a1a"), false)
	Toon.box(m, Vector3(0.08, 0.20, 0.10), Vector3(0, -0.14, 0.2), Color("8a5a2b"), false)
	return Vector3(0, 0.03, -0.82)


func _model_sniper(m: Node3D) -> Vector3:
	Toon.box(m, Vector3(0.08, 0.12, 0.60), Vector3(0, 0, 0.05), Color("2b3a2f"), false)
	Toon.box(m, Vector3(0.045, 0.045, 0.95), Vector3(0, 0.02, -0.65), Color("1d1f26"), false)
	Toon.box(m, Vector3(0.07, 0.20, 0.10), Vector3(0, -0.14, 0.15), Color("2b3a2f"), false)
	Toon.box(m, Vector3(0.09, 0.15, 0.30), Vector3(0, -0.02, 0.4), Color("3c4f3d"), false)
	# Mira telescópica
	Toon.cyl(m, 0.04, 0.38, Vector3(0, 0.12, -0.1), Color("ffb347"), false, PI / 2.0)
	Toon.cyl(m, 0.055, 0.10, Vector3(0, 0.12, -0.3), Color("1d1f26"), false, PI / 2.0)
	return Vector3(0, 0.02, -1.15)


# ------------------------------------------------------------------ utilidades

func _def() -> Dictionary:
	return Weapons.DEFS[cur]


func cur_ammo() -> int:
	return int(ammo[cur])


func cur_reserve() -> int:
	return int(reserve[cur])


func weapon_name() -> String:
	return String(_def()["name"])


func scope_kind() -> String:
	if scoped:
		return String(_def()["scope"])
	return ""


func _equip(id: String) -> void:
	cur = id
	_reload_id += 1
	reloading = false
	_set_scope(false)
	for k in _models:
		var mdl: Node3D = _models[k]
		mdl.visible = (k == id)
	if _tween != null:
		_tween.kill()
	_reload_offset = 0.35
	_tween = create_tween()
	_tween.tween_property(self, "_reload_offset", 0.0, 0.25)
	_cd = 0.25
	stats_changed.emit()


func swap_weapon() -> void:
	if owned.size() < 2 or not alive:
		return
	var i := owned.find(cur)
	_equip(owned[(i + 1) % owned.size()])


func toggle_scope() -> void:
	if not alive:
		return
	var d := _def()
	if String(d["scope"]) == "":
		message_posted.emit("Esta arma no tiene mira")
		return
	if reloading:
		return
	_set_scope(not scoped)


func _set_scope(v: bool) -> void:
	scoped = v
	var d := _def()
	var mdl: Node3D = _models.get(cur)
	if mdl != null:
		mdl.visible = not (v and String(d["scope"]) == "sniper")


# ------------------------------------------------------------------ bucle

func _physics_process(delta: float) -> void:
	if not alive or controls == null:
		return

	# Mirar (más lento con zoom)
	var ld := controls.consume_look()
	var sens := LOOK_SENS * (_cam.fov / BASE_FOV)
	rotate_y(-ld.x * sens)
	_pitch = clampf(_pitch - ld.y * sens, -1.45, 1.45)
	_head.rotation.x = _pitch

	# Mover
	var mv := controls.move_vec
	var dir := global_transform.basis * Vector3(mv.x, 0.0, mv.y)
	dir.y = 0.0
	var spd := SPEED * (0.55 if scoped else 1.0)
	velocity.x = dir.x * spd
	velocity.z = dir.z * spd
	var jump := controls.consume_jump()
	if is_on_floor():
		velocity.y = 0.0
		if jump:
			velocity.y = JUMP_V
	else:
		velocity.y -= GRAV * delta
	move_and_slide()

	# Acciones
	_cd -= delta
	_tap_buf = maxf(_tap_buf - delta, 0.0)
	if controls.consume_fire_tap():
		_tap_buf = 0.2
	if controls.consume_reload():
		reload()
	if controls.consume_swap():
		swap_weapon()
	if controls.consume_scope():
		toggle_scope()

	var d := _def()
	var wants := false
	if bool(d["auto"]):
		wants = controls.fire_held
	else:
		wants = _tap_buf > 0.0
	if wants and _cd <= 0.0 and not reloading:
		_shoot()
		_tap_buf = 0.0


func _process(delta: float) -> void:
	if _flash_t > 0.0:
		_flash_t -= delta
		if _flash_t <= 0.0:
			for k in _flashes:
				var f: MeshInstance3D = _flashes[k]
				f.visible = false

	_kick = lerpf(_kick, 0.0, minf(delta * 14.0, 1.0))
	var d := _def()
	var base := HOME
	var zoom_target := 1.0
	if scoped:
		base = d["ads"]
		zoom_target = float(d["zoom"])
	var target := base + Vector3(0.0, -_reload_offset, _kick)
	_holder.position = _holder.position.lerp(target, minf(delta * 18.0, 1.0))
	_cam.fov = lerpf(_cam.fov, BASE_FOV / zoom_target, minf(delta * 12.0, 1.0))


func _shoot() -> void:
	if int(ammo[cur]) <= 0:
		reload()
		return
	var d := _def()
	ammo[cur] = int(ammo[cur]) - 1
	_cd = float(d["rate"])
	stats_changed.emit()

	var origin := _cam.global_position
	var spread := float(d["spread"]) * (0.35 if scoped else 1.0)
	var mk: Node3D = _muzzles[cur]
	var tip := mk.global_position
	var dmg_base := float(d["dmg"])
	var hit_any := false
	var killed_any := false

	for i in int(d["pellets"]):
		var off := Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * spread
		var dir := (_cam.global_transform.basis * (Vector3(0, 0, -1) + off)).normalized()
		var to := origin + dir * 160.0
		var q := PhysicsRayQueryParameters3D.create(origin, to, 5) # mundo(1) + enemigos(4)
		var res := get_world_3d().direct_space_state.intersect_ray(q)
		var end := to
		if not res.is_empty():
			end = res["position"]
			var enemy := res["collider"] as Enemy
			if enemy != null:
				var dmg := dmg_base
				if end.y - enemy.global_position.y > 1.5:
					dmg *= 2.0 # cabeza
				var killed: bool = enemy.take_damage(dmg, self)
				hit_any = true
				if killed:
					killed_any = true
					kills += 1
				Fx.spark(get_parent(), end, Color(1.0, 0.3, 0.3))
			else:
				Fx.spark(get_parent(), end, Color(1.0, 0.85, 0.5))
		Fx.tracer(get_parent(), tip, end)

	if hit_any:
		hit_confirmed.emit(killed_any)
	if killed_any:
		stats_changed.emit()

	_kick = float(d["recoil"])
	var fl: MeshInstance3D = _flashes[cur]
	fl.visible = true
	_flash_t = 0.04


func reload() -> void:
	var d := _def()
	var mag := int(d["mag"])
	if reloading or int(ammo[cur]) >= mag or int(reserve[cur]) <= 0 or not alive:
		return
	reloading = true
	_set_scope(false)
	stats_changed.emit()
	_reload_id += 1
	var my_id := _reload_id
	var t := float(d["reload"])
	if _tween != null:
		_tween.kill()
	_tween = create_tween()
	_tween.tween_property(self, "_reload_offset", 0.4, 0.25)
	_tween.tween_interval(maxf(t - 0.5, 0.05))
	_tween.tween_property(self, "_reload_offset", 0.0, 0.25)
	await get_tree().create_timer(t).timeout
	if my_id != _reload_id or not alive:
		return
	var take := mini(mag - int(ammo[cur]), int(reserve[cur]))
	ammo[cur] = int(ammo[cur]) + take
	reserve[cur] = int(reserve[cur]) - take
	reloading = false
	stats_changed.emit()


func take_damage(amount: float, _source: Node = null) -> bool:
	if not alive:
		return false
	health = maxf(health - amount, 0.0)
	hit_taken.emit()
	stats_changed.emit()
	if health <= 0.0:
		alive = false
		_set_scope(false)
		died.emit()
		return true
	return false


func pickup(kind: String) -> bool:
	if kind == "health":
		if health >= 100.0:
			return false
		health = minf(100.0, health + 35.0)
	elif kind == "ammo":
		for id in Weapons.DEFS:
			var d: Dictionary = Weapons.DEFS[id]
			reserve[id] = int(reserve[id]) + int(d["mag"]) * 2
	elif kind.begins_with("weapon_"):
		var wid := kind.substr(7)
		if not Weapons.DEFS.has(wid):
			return false
		var wd: Dictionary = Weapons.DEFS[wid]
		if owned.has(wid):
			reserve[wid] = int(reserve[wid]) + int(wd["mag"]) * 2
			message_posted.emit("+ munición: " + String(wd["name"]))
		else:
			owned.append(wid)
			_equip(wid)
			message_posted.emit("¡Conseguiste: " + String(wd["name"]) + "!")
	else:
		return false
	stats_changed.emit()
	return true
