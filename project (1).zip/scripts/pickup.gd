class_name Pickup
extends Area3D
## Botiquín (verde/blanco) o caja de munición (amarilla). Gira y flota.

var kind := "health"

var _mesh: Node3D
var _t := 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape3D.new()
	var ss := SphereShape3D.new()
	ss.radius = 1.4
	cs.shape = ss
	cs.position.y = 0.8
	add_child(cs)

	_mesh = Node3D.new()
	_mesh.position.y = 0.8
	add_child(_mesh)
	_t = randf() * TAU

	if kind == "health":
		Toon.box(_mesh, Vector3(0.7, 0.7, 0.7), Vector3.ZERO, Color("f4f4f4"), false, 0.0, true)
		Toon.box(_mesh, Vector3(0.5, 0.14, 0.74), Vector3.ZERO, Color("e0322b"), false)
		Toon.box(_mesh, Vector3(0.14, 0.5, 0.74), Vector3.ZERO, Color("e0322b"), false)
	elif kind.begins_with("weapon_"):
		var wid := kind.substr(7)
		var body_col := Color("8a5a2b") if wid == "shotgun" else Color("3c4f3d")
		Toon.box(_mesh, Vector3(1.1, 0.16, 0.2), Vector3.ZERO, body_col, false, 0.0, true)
		Toon.box(_mesh, Vector3(0.5, 0.14, 0.22), Vector3(-0.35, -0.12, 0), Color("1d1f26"), false)
		Toon.cyl(self, 0.85, 0.04, Vector3(0, 0.05, 0), Color(1.0, 0.9, 0.3), false)
		if Weapons.DEFS.has(wid):
			var lb := Label3D.new()
			lb.text = String(Weapons.DEFS[wid]["name"])
			lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
			lb.font_size = 56
			lb.pixel_size = 0.008
			lb.outline_size = 14
			lb.modulate = Color(1.0, 0.95, 0.5)
			lb.position = Vector3(0, 1.9, 0)
			add_child(lb)
	else:
		Toon.box(_mesh, Vector3(0.8, 0.5, 0.55), Vector3.ZERO, Color("f2c230"), false, 0.0, true)
		Toon.box(_mesh, Vector3(0.82, 0.12, 0.57), Vector3(0, 0.0, 0), Color("3a3a3a"), false)

	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_t += delta
	_mesh.rotation.y += delta * 1.8
	_mesh.position.y = 0.8 + sin(_t * 2.5) * 0.12


func _on_body_entered(body: Node3D) -> void:
	var p := body as Player
	if p != null and p.pickup(kind):
		queue_free()
