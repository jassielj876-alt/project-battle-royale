class_name TouchControls
extends Control
## Controles táctiles: joystick flotante (izquierda), mirar arrastrando (derecha),
## botones FUEGO / SALTAR / RECARGAR / MIRA / ARMA. Soporta multitoque.

const JOY_R := 120.0

var move_vec := Vector2.ZERO
var fire_held := false

var _look := Vector2.ZERO
var _jump := false
var _reload := false
var _scope := false
var _swap := false
var _fire_tap := false

var _move_id := -1
var _look_id := -1
var _fire_id := -1
var _move_origin := Vector2.ZERO
var _move_cur := Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func fire_center() -> Vector2:
	return Vector2(size.x - 190.0, size.y - 190.0)


func jump_center() -> Vector2:
	return Vector2(size.x - 360.0, size.y - 95.0)


func reload_center() -> Vector2:
	return Vector2(size.x - 100.0, size.y - 380.0)


func scope_center() -> Vector2:
	return Vector2(size.x - 380.0, size.y - 250.0)


func swap_center() -> Vector2:
	return Vector2(size.x - 250.0, size.y - 400.0)


func consume_look() -> Vector2:
	var l := _look
	_look = Vector2.ZERO
	return l


func consume_jump() -> bool:
	var j := _jump
	_jump = false
	return j


func consume_reload() -> bool:
	var r := _reload
	_reload = false
	return r


func consume_scope() -> bool:
	var s := _scope
	_scope = false
	return s


func consume_swap() -> bool:
	var s := _swap
	_swap = false
	return s


func consume_fire_tap() -> bool:
	var f := _fire_tap
	_fire_tap = false
	return f


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var p: Vector2 = event.position
		if event.pressed:
			if p.distance_to(fire_center()) <= 100.0 and _fire_id == -1:
				_fire_id = event.index
				fire_held = true
				_fire_tap = true
			elif p.distance_to(jump_center()) <= 75.0:
				_jump = true
			elif p.distance_to(reload_center()) <= 66.0:
				_reload = true
			elif p.distance_to(scope_center()) <= 66.0:
				_scope = true
			elif p.distance_to(swap_center()) <= 66.0:
				_swap = true
			elif p.x < size.x * 0.42:
				if _move_id == -1:
					_move_id = event.index
					_move_origin = p
					_move_cur = p
					_update_move()
			else:
				if _look_id == -1:
					_look_id = event.index
		else:
			if event.index == _move_id:
				_move_id = -1
				move_vec = Vector2.ZERO
			elif event.index == _look_id:
				_look_id = -1
			elif event.index == _fire_id:
				_fire_id = -1
				fire_held = false
	elif event is InputEventScreenDrag:
		if event.index == _move_id:
			_move_cur = event.position
			_update_move()
		elif event.index == _look_id or event.index == _fire_id:
			# Arrastrar el dedo del botón de fuego también gira la cámara.
			_look += event.relative


func _update_move() -> void:
	var d := _move_cur - _move_origin
	if d.length() > JOY_R:
		d = d.normalized() * JOY_R
		_move_cur = _move_origin + d
	var v := d / JOY_R
	if v.length() < 0.12:
		v = Vector2.ZERO
	move_vec = v


func _process(_delta: float) -> void:
	queue_redraw()


func _button(center: Vector2, radius: float, fill: Color, label: String, fs: int) -> void:
	var font := ThemeDB.fallback_font
	draw_circle(center, radius, fill)
	draw_arc(center, radius, 0.0, TAU, 32, Color(1, 1, 1, 0.85), 4.0)
	draw_string(font, center + Vector2(-radius, fs * 0.35), label, HORIZONTAL_ALIGNMENT_CENTER, radius * 2.0, fs, Color.WHITE)


func _draw() -> void:
	var font := ThemeDB.fallback_font
	# Joystick
	var base := _move_origin if _move_id != -1 else Vector2(210.0, size.y - 210.0)
	var knob := _move_cur if _move_id != -1 else base
	draw_circle(base, JOY_R, Color(1, 1, 1, 0.10))
	draw_arc(base, JOY_R, 0.0, TAU, 48, Color(1, 1, 1, 0.45), 3.0)
	draw_circle(knob, 48.0, Color(1, 1, 1, 0.38))
	# Botón de fuego
	var fc := fire_center()
	draw_circle(fc, 85.0, Color(1.0, 0.3, 0.2, 0.55 if fire_held else 0.30))
	draw_arc(fc, 85.0, 0.0, TAU, 40, Color(1, 1, 1, 0.6), 3.0)
	draw_string(font, fc + Vector2(-60.0, 9.0), "FUEGO", HORIZONTAL_ALIGNMENT_CENTER, 120.0, 26, Color.WHITE)
	# Saltar
	var jc := jump_center()
	draw_circle(jc, 60.0, Color(0.3, 0.7, 1.0, 0.30))
	draw_arc(jc, 60.0, 0.0, TAU, 32, Color(1, 1, 1, 0.6), 3.0)
	draw_string(font, jc + Vector2(-50.0, 8.0), "SALTAR", HORIZONTAL_ALIGNMENT_CENTER, 100.0, 20, Color.WHITE)
	# Recargar, mira y cambiar arma
	_button(reload_center(), 52.0, Color(0.9, 0.55, 0.05, 0.60), "RECARG", 19)
	_button(scope_center(), 52.0, Color(0.1, 0.65, 0.75, 0.60), "MIRA", 21)
	_button(swap_center(), 52.0, Color(0.55, 0.3, 0.85, 0.60), "ARMA", 21)
