extends Node3D
## Escena principal: arma todo el juego por código (entorno, mapa, jugador,
## enemigos, tormenta y UI). No hay que diseñar nada a mano en el editor.

const ENEMY_COUNT := 19
const SHADOWS := true # ponlo en false si tu celular va lento

var world: GameWorld
var player: Player
var storm: StormZone
var hud: GameHUD
var controls: TouchControls

var _enemies_alive := 0
var _ended := false


func _ready() -> void:
	randomize()
	_setup_environment()

	world = GameWorld.new()
	add_child(world)
	world.build()

	storm = StormZone.new()
	add_child(storm)

	_setup_ui()
	_spawn_player()
	_spawn_enemies()

	storm.player = player
	storm.phase_changed.connect(func(t: String): hud.show_message(t, 4.0))
	hud.show_message("SANDSTORM ROYALE - ¡Sé el último en pie!", 5.0)


func _setup_environment() -> void:
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("3d8fe0")
	sky_mat.sky_horizon_color = Color("bfe3ff")
	sky_mat.ground_horizon_color = Color("e8d4a2")
	sky_mat.ground_bottom_color = Color("d9b878")
	var sky := Sky.new()
	sky.sky_material = sky_mat

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("ffe9c9")
	env.ambient_light_energy = 0.35
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color("f3dfb0")
	env.fog_density = 0.0015
	env.fog_sky_affect = 0.0 # que la niebla no tiñe el cielo de rosa

	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52.0, -35.0, 0.0)
	sun.light_color = Color("fff1d6")
	sun.light_energy = 0.8
	sun.shadow_enabled = SHADOWS
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)


func _setup_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = GameHUD.new()
	layer.add_child(hud)
	controls = TouchControls.new()
	layer.add_child(controls)
	hud.restart_requested.connect(func(): get_tree().reload_current_scene())


func _spawn_player() -> void:
	player = Player.new()
	player.controls = controls
	var p := world.random_free_point(70.0, 105.0)
	p.y = 0.3
	player.position = p
	player.rotation.y = atan2(p.x, p.z) # mirar hacia el centro
	add_child(player)
	player.hit_taken.connect(hud.flash_damage)
	player.hit_confirmed.connect(hud.flash_hit)
	player.died.connect(_on_player_died)
	player.message_posted.connect(func(t: String): hud.show_message(t, 2.5))


func _spawn_enemies() -> void:
	for i in ENEMY_COUNT:
		var p := Vector3.ZERO
		for attempt in 20:
			p = world.random_free_point(0.0, 108.0)
			if p.distance_to(player.position) > 45.0:
				break
		p.y = 0.3
		var e := Enemy.new()
		e.position = p
		e.target = player
		e.storm = storm
		add_child(e)
		e.died.connect(_on_enemy_died)
		_enemies_alive += 1


func _process(_delta: float) -> void:
	if player == null:
		return
	hud.health = player.health
	hud.ammo = player.cur_ammo()
	hud.reserve = player.cur_reserve()
	hud.weapon_name = player.weapon_name()
	hud.scope_kind = player.scope_kind()
	hud.reloading = player.reloading
	hud.kills = player.kills
	hud.alive_count = _enemies_alive + (1 if player.alive else 0)
	hud.zone_text = storm.status_text()
	hud.in_zone = not storm.is_outside(player.global_position)

	var to_c := storm.center - player.global_position
	to_c.y = 0.0
	var local := player.global_transform.basis.inverse() * to_c
	hud.zone_angle = atan2(local.x, -local.z)
	hud.zone_dist = maxf(to_c.length() - storm.radius, 0.0) if not hud.in_zone else maxf(storm.radius - to_c.length(), 0.0)


func _on_enemy_died(_e: Enemy) -> void:
	_enemies_alive -= 1
	if _enemies_alive <= 0 and player.alive and not _ended:
		_end(true)


func _on_player_died() -> void:
	await get_tree().create_timer(1.0).timeout
	if not _ended:
		_end(false)


func _end(victory: bool) -> void:
	_ended = true
	controls.hide()
	controls.set_process_input(false)
	if victory:
		hud.show_end("¡VICTORIA!", "Bajas: %d" % player.kills, Color(1.0, 0.85, 0.2))
	else:
		hud.show_end("ELIMINADO", "Bajas: %d   |   Quedaban: %d" % [player.kills, _enemies_alive], Color(1.0, 0.3, 0.25))
