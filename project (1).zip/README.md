# SANDSTORM ROYALE (Godot 4.3+)

Armas: pistola, rifle (mira punto rojo x1.8), escopeta y francotirador (mira telescópica x4).
Botones: MIRA = apuntar/zoom, ARMA = cambiar de arma. Escopeta y francotirador se recogen del suelo.

Battle Royale 3D en primera persona, estilo caricatura, mapa de desierto militar.
Todo el mundo se genera por código: no hay que diseñar nada a mano.

## Controles táctiles
- Joystick izquierdo: moverse (aparece donde pones el dedo)
- Arrastrar a la derecha: mirar
- FUEGO: disparar (arrastra el dedo sobre el botón para apuntar disparando)
- SALTAR / RECARG

## Estructura
- `main.tscn` + `scripts/main.gd`: escena principal, arma todo
- `scripts/game_world.gd`: mapa (base militar, puestos, torres, tanques, cactus...)
- `scripts/player.gd`, `scripts/enemy.gd`: jugador y enemigos con IA
- `scripts/storm_zone.gd`: tormenta que se encoge por fases
- `scripts/touch_controls.gd`, `scripts/game_hud.gd`: controles y HUD
- `shaders/`: cel-shading y contorno caricaturesco

## Ajustes rápidos
- Menos enemigos: `ENEMY_COUNT` en `main.gd`
- Más fluidez en celulares lentos: `SHADOWS := false` en `main.gd`
- Sensibilidad de cámara: `LOOK_SENS` en `player.gd`
