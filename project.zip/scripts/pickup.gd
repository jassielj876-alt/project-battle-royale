class_name Pickup
extends Area3D
## Botiquín (verde/blanco) o caja de munición (amarilla). Gira y flota.

var kind := "health"

var _mesh: Node3D
var _t := 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var cs := CollisionShape3D.new()
	var ss := SphereShape3D.new()
	ss.radius = 1.4
	cs.shape = ss
	cs.position.y = 0.8
	add_child(cs)

	_mesh = Node3D.new()
	_mesh.position.y = 0.8
	add_child(_mesh)
	_t = randf() * TAU

	if kind == "health":
		Toon.box(_mesh, Vector3(0.7, 0.7, 0.7), Vector3.ZERO, Color("f4f4f4"), false, 0.0, true)
		Toon.box(_mesh, Vector3(0.5, 0.14, 0.74), Vector3.ZERO, Color("e0322b"), false)
		Toon.box(_mesh, Vector3(0.14, 0.5, 0.74), Vector3.ZERO, Color("e0322b"), false)
	else:
		Toon.box(_mesh, Vector3(0.8, 0.5, 0.55), Vector3.ZERO, Color("f2c230"), false, 0.0, true)
		Toon.box(_mesh, Vector3(0.82, 0.12, 0.57), Vector3(0, 0.0, 0), Color("3a3a3a"), false)

	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_t += delta
	_mesh.rotation.y += delta * 1.8
	_mesh.position.y = 0.8 + sin(_t * 2.5) * 0.12


func _on_body_entered(body: Node3D) -> void:
	var p := body as Player
	if p != null and p.pickup(kind):
		queue_free()
