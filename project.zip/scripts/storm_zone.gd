class_name StormZone
extends Node3D
## Zona segura que se encoge por fases (tormenta). Daña a quien quede fuera.

signal phase_changed(text: String)

var center := Vector3.ZERO
var radius := 140.0
var player: Player

var _phases := [
	{"wait": 40.0, "shrink": 50.0, "radius": 85.0, "dps": 2.0},
	{"wait": 30.0, "shrink": 45.0, "radius": 50.0, "dps": 4.0},
	{"wait": 25.0, "shrink": 40.0, "radius": 25.0, "dps": 6.0},
	{"wait": 20.0, "shrink": 35.0, "radius": 10.0, "dps": 10.0},
	{"wait": 15.0, "shrink": 30.0, "radius": 2.0, "dps": 15.0},
]
var _i := 0
var _t := 0.0
var _shrinking := false
var _from_radius := 140.0
var _from_center := Vector3.ZERO
var _to_center := Vector3.ZERO
var _dps := 1.0
var _tick := 0.0
var _wall: MeshInstance3D


func _ready() -> void:
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = 70.0
	cm.radial_segments = 64
	cm.rings = 1
	cm.cap_top = false
	cm.cap_bottom = false
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.albedo_color = Color(0.85, 0.15, 0.3, 0.28)
	_wall = MeshInstance3D.new()
	_wall.mesh = cm
	_wall.material_override = m
	_wall.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_wall)
	_update_wall()


func is_outside(pos: Vector3) -> bool:
	return Vector2(pos.x - center.x, pos.z - center.z).length() > radius


func status_text() -> String:
	if _i >= _phases.size():
		return "ZONA FINAL"
	if _shrinking:
		return "ZONA CERRÁNDOSE"
	var left := maxf(float(_phases[_i]["wait"]) - _t, 0.0)
	return "ZONA %d:%02d" % [int(left) / 60, int(left) % 60]


func _process(delta: float) -> void:
	if _i < _phases.size():
		var ph: Dictionary = _phases[_i]
		_t += delta
		if not _shrinking:
			if _t >= float(ph["wait"]):
				_shrinking = true
				_t = 0.0
				_from_radius = radius
				_from_center = center
				var tr := float(ph["radius"])
				var ang := randf() * TAU
				var off := (radius - tr) * sqrt(randf()) * 0.9
				_to_center = center + Vector3(cos(ang), 0.0, sin(ang)) * off
				_dps = float(ph["dps"])
				phase_changed.emit("¡LA TORMENTA SE CIERRA!")
		else:
			var k := clampf(_t / float(ph["shrink"]), 0.0, 1.0)
			radius = lerpf(_from_radius, float(ph["radius"]), k)
			center = _from_center.lerp(_to_center, k)
			if k >= 1.0:
				_shrinking = false
				_t = 0.0
				_i += 1
				if _i < _phases.size():
					phase_changed.emit("Nueva zona marcada")
	_update_wall()

	_tick += delta
	if _tick >= 1.0:
		_tick = 0.0
		_apply_damage()


func _update_wall() -> void:
	_wall.position = Vector3(center.x, 30.0, center.z)
	_wall.scale = Vector3(radius, 1.0, radius)


func _apply_damage() -> void:
	if player != null and player.alive and is_outside(player.global_position):
		player.take_damage(_dps)
	for e in get_tree().get_nodes_in_group("enemies"):
		if e.alive and is_outside(e.global_position):
			e.take_damage(_dps)
