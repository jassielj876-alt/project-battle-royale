class_name Player
extends CharacterBody3D
## Jugador en primera persona con arma automática de rayo (hitscan).

signal stats_changed
signal hit_taken
signal hit_confirmed(killed: bool)
signal died

const SPEED := 8.0
const JUMP_V := 7.0
const GRAV := 20.0
const LOOK_SENS := 0.0045
const MAG := 30
const DAMAGE := 22.0
const FIRE_RATE := 0.11

var controls: TouchControls
var health := 100.0
var ammo := MAG
var reserve := 120
var reloading := false
var alive := true
var kills := 0

var _head: Node3D
var _cam: Camera3D
var _weapon: Node3D
var _flash: MeshInstance3D
var _pitch := 0.0
var _cd := 0.0
var _flash_t := 0.0
var _weapon_home := Vector3(0.28, -0.26, -0.55)


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)

	_head = Node3D.new()
	_head.position.y = 1.6
	add_child(_head)

	_cam = Camera3D.new()
	_cam.fov = 78.0
	_cam.near = 0.05
	_cam.far = 400.0
	_head.add_child(_cam)
	_cam.make_current()

	_build_weapon()


func _build_weapon() -> void:
	_weapon = Node3D.new()
	_weapon.position = _weapon_home
	_cam.add_child(_weapon)
	Toon.box(_weapon, Vector3(0.10, 0.14, 0.55), Vector3(0, 0, 0), Color("2f3542"), false)
	Toon.box(_weapon, Vector3(0.07, 0.07, 0.35), Vector3(0, 0.02, -0.42), Color("ff8a1f"), false)
	Toon.box(_weapon, Vector3(0.08, 0.22, 0.10), Vector3(0, -0.15, 0.05), Color("ffb347"), false)
	Toon.box(_weapon, Vector3(0.07, 0.16, 0.08), Vector3(0, -0.12, 0.25), Color("2f3542"), false)

	var sm := SphereMesh.new()
	sm.radius = 0.09
	sm.height = 0.18
	_flash = MeshInstance3D.new()
	_flash.mesh = sm
	var fmat := StandardMaterial3D.new()
	fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fmat.albedo_color = Color(1.0, 0.85, 0.3)
	_flash.material_override = fmat
	_flash.position = Vector3(0, 0.02, -0.65)
	_flash.visible = false
	_weapon.add_child(_flash)


func _physics_process(delta: float) -> void:
	if not alive or controls == null:
		return

	# Mirar
	var ld := controls.consume_look()
	rotate_y(-ld.x * LOOK_SENS)
	_pitch = clampf(_pitch - ld.y * LOOK_SENS, -1.45, 1.45)
	_head.rotation.x = _pitch

	# Mover
	var mv := controls.move_vec
	var dir := global_transform.basis * Vector3(mv.x, 0.0, mv.y)
	dir.y = 0.0
	velocity.x = dir.x * SPEED
	velocity.z = dir.z * SPEED
	var jump := controls.consume_jump()
	if is_on_floor():
		velocity.y = 0.0
		if jump:
			velocity.y = JUMP_V
	else:
		velocity.y -= GRAV * delta
	move_and_slide()

	# Disparar / recargar
	_cd -= delta
	if controls.consume_reload():
		reload()
	if controls.fire_held and _cd <= 0.0 and not reloading:
		_shoot()


func _process(delta: float) -> void:
	if _flash_t > 0.0:
		_flash_t -= delta
		if _flash_t <= 0.0:
			_flash.visible = false
	_weapon.position.z = lerpf(_weapon.position.z, _weapon_home.z, minf(delta * 20.0, 1.0))


func _shoot() -> void:
	if ammo <= 0:
		reload()
		return
	ammo -= 1
	_cd = FIRE_RATE
	stats_changed.emit()

	var origin := _cam.global_position
	var spread := Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * 0.012
	var dir := (_cam.global_transform.basis * (Vector3(0, 0, -1) + spread)).normalized()
	var to := origin + dir * 160.0
	var q := PhysicsRayQueryParameters3D.create(origin, to, 5) # capas: mundo(1) + enemigos(4)
	var res := get_world_3d().direct_space_state.intersect_ray(q)
	var end := to
	if not res.is_empty():
		end = res["position"]
		var enemy := res["collider"] as Enemy
		if enemy != null:
			var dmg := DAMAGE
			if end.y - enemy.global_position.y > 1.5:
				dmg *= 2.0 # disparo a la cabeza
			var killed: bool = enemy.take_damage(dmg, self)
			if killed:
				kills += 1
				stats_changed.emit()
			hit_confirmed.emit(killed)
			Fx.spark(get_parent(), end, Color(1.0, 0.3, 0.3))
		else:
			Fx.spark(get_parent(), end, Color(1.0, 0.85, 0.5))
	Fx.tracer(get_parent(), _flash.global_position, end)

	_weapon.position.z = _weapon_home.z + 0.07
	_flash.visible = true
	_flash_t = 0.04


func reload() -> void:
	if reloading or ammo == MAG or reserve <= 0 or not alive:
		return
	reloading = true
	stats_changed.emit()
	var tw := create_tween()
	tw.tween_property(_weapon, "position:y", _weapon_home.y - 0.4, 0.25)
	tw.tween_interval(1.0)
	tw.tween_property(_weapon, "position:y", _weapon_home.y, 0.25)
	await get_tree().create_timer(1.5).timeout
	if not alive:
		return
	var take := mini(MAG - ammo, reserve)
	ammo += take
	reserve -= take
	reloading = false
	stats_changed.emit()


func take_damage(amount: float, _source: Node = null) -> bool:
	if not alive:
		return false
	health = maxf(health - amount, 0.0)
	hit_taken.emit()
	stats_changed.emit()
	if health <= 0.0:
		alive = false
		died.emit()
		return true
	return false


func pickup(kind: String) -> bool:
	if kind == "health":
		if health >= 100.0:
			return false
		health = minf(100.0, health + 35.0)
	else:
		reserve += 60
	stats_changed.emit()
	return true
