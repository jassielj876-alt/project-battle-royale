class_name Enemy
extends CharacterBody3D
## Enemigo con IA: patrulla, ve al jugador (línea de visión), lo persigue,
## dispara, hace strafe y huye de la tormenta.

signal died(enemy: Enemy)

const WALK := 3.2
const RUN := 5.6
const GRAV := 22.0
const SIGHT := 48.0
const MAX_HP := 70.0
const DMG := 5.0

var target: Player
var storm: StormZone
var health := MAX_HP
var alive := true

var _visual: Node3D
var _gun_tip: Node3D
var _last_known := Vector3.ZERO
var _memory := 0.0
var _can_see := false
var _los_t := 0.0
var _shoot_cd := 1.0
var _wander_dir := Vector3.ZERO
var _wander_t := 0.0
var _avoid_t := 0.0
var _avoid_sign := 1.0
var _strafe := 1.0
var _strafe_t := 0.0


func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	_build_visual()
	_shoot_cd = randf_range(0.8, 2.0)
	_wander_dir = _random_dir()
	_wander_t = randf_range(1.0, 3.0)
	rotation.y = randf() * TAU


func _build_visual() -> void:
	var palette := [Color("ff5a4d"), Color("4d9bff"), Color("a35dff"), Color("2fd1a0"), Color("ff9f1c"), Color("ff5ea8")]
	var col: Color = palette[randi() % palette.size()]
	_visual = Node3D.new()
	add_child(_visual)

	var body := CapsuleMesh.new()
	body.radius = 0.38
	body.height = 1.2
	Toon.mesh(_visual, body, Vector3(0, 0.95, 0), col, true)

	var head := SphereMesh.new()
	head.radius = 0.3
	head.height = 0.6
	Toon.mesh(_visual, head, Vector3(0, 1.66, 0), Color("ffd2a8"), true)

	var helmet := SphereMesh.new()
	helmet.radius = 0.33
	helmet.height = 0.5
	Toon.mesh(_visual, helmet, Vector3(0, 1.76, 0.02), col.darkened(0.35), true)

	Toon.box(_visual, Vector3(0.08, 0.1, 0.05), Vector3(-0.11, 1.64, -0.27), Color("101010"), false)
	Toon.box(_visual, Vector3(0.08, 0.1, 0.05), Vector3(0.11, 1.64, -0.27), Color("101010"), false)
	Toon.box(_visual, Vector3(0.2, 0.4, 0.25), Vector3(-0.17, 0.2, 0), Color("3b3f4a"), false)
	Toon.box(_visual, Vector3(0.2, 0.4, 0.25), Vector3(0.17, 0.2, 0), Color("3b3f4a"), false)
	Toon.box(_visual, Vector3(0.09, 0.11, 0.62), Vector3(0.3, 1.05, -0.45), Color("2a2a2a"), false)

	_gun_tip = Node3D.new()
	_gun_tip.position = Vector3(0.3, 1.05, -0.85)
	_visual.add_child(_gun_tip)


func _random_dir() -> Vector3:
	var a := randf() * TAU
	return Vector3(cos(a), 0.0, sin(a))


func _physics_process(delta: float) -> void:
	if not alive:
		return
	_visual.scale = _visual.scale.lerp(Vector3.ONE, minf(delta * 10.0, 1.0))

	if is_on_floor():
		velocity.y = 0.0
	else:
		velocity.y -= GRAV * delta

	_update_sight(delta)

	var want := Vector3.ZERO
	var speed := WALK
	var face := Vector3.ZERO

	var outside := storm != null and storm.is_outside(global_position)
	if outside:
		# Huir de la tormenta hacia el centro de la zona segura
		want = storm.center - global_position
		want.y = 0.0
		speed = RUN
		face = want
	elif _can_see and target != null:
		var to_t := target.global_position - global_position
		to_t.y = 0.0
		var dist := to_t.length()
		var dir := to_t.normalized()
		face = dir
		_strafe_t -= delta
		if _strafe_t <= 0.0:
			_strafe = -1.0 if randf() < 0.5 else 1.0
			_strafe_t = randf_range(1.0, 2.5)
		var side := Vector3(-dir.z, 0.0, dir.x) * _strafe
		if dist > 18.0:
			want = dir + side * 0.3
			speed = RUN
		elif dist < 7.0:
			want = -dir * 0.8 + side
		else:
			want = side
		_shoot_cd -= delta
		if _shoot_cd <= 0.0 and dist < SIGHT - 6.0:
			_shoot_cd = randf_range(0.5, 1.1)
			_fire(dist)
	elif _memory > 0.0:
		_memory -= delta
		var to_l := _last_known - global_position
		to_l.y = 0.0
		if to_l.length() < 2.5:
			_memory = 0.0
		else:
			want = to_l
			speed = RUN
			face = want
	else:
		_wander_t -= delta
		if _wander_t <= 0.0:
			_wander_t = randf_range(2.0, 5.0)
			_wander_dir = _random_dir() if randf() < 0.75 else Vector3.ZERO
		if absf(global_position.x) > 108.0 or absf(global_position.z) > 108.0:
			_wander_dir = Vector3(-global_position.x, 0.0, -global_position.z).normalized()
		want = _wander_dir
		face = want

	if want.length() > 0.01:
		want = want.normalized()
		if _avoid_t > 0.0:
			_avoid_t -= delta
			want = want.rotated(Vector3.UP, deg_to_rad(80.0) * _avoid_sign)
	velocity.x = want.x * speed
	velocity.z = want.z * speed
	move_and_slide()

	if want != Vector3.ZERO and is_on_wall() and _avoid_t <= 0.0:
		_avoid_t = randf_range(0.5, 1.0)
		_avoid_sign = -1.0 if randf() < 0.5 else 1.0

	var look_dir := face if face.length() > 0.01 else want
	_face(look_dir, delta)


func _face(dir: Vector3, delta: float) -> void:
	if dir.length() < 0.01:
		return
	var yaw := atan2(-dir.x, -dir.z)
	rotation.y = lerp_angle(rotation.y, yaw, clampf(8.0 * delta, 0.0, 1.0))


func _update_sight(delta: float) -> void:
	_los_t -= delta
	if _los_t > 0.0:
		return
	_los_t = 0.2
	_can_see = false
	if target == null or not target.alive:
		return
	var from := global_position + Vector3(0, 1.5, 0)
	var to := target.global_position + Vector3(0, 1.2, 0)
	if from.distance_to(to) > SIGHT:
		return
	var q := PhysicsRayQueryParameters3D.create(from, to, 1)
	if get_world_3d().direct_space_state.intersect_ray(q).is_empty():
		_can_see = true
		_last_known = target.global_position
		_memory = 6.0


func _fire(dist: float) -> void:
	var chance := clampf(0.8 - dist / 55.0, 0.12, 0.7)
	var from := _gun_tip.global_position
	var aim := target.global_position + Vector3(0, 1.2, 0)
	var hit := randf() < chance
	var end := aim
	if not hit:
		end = aim + Vector3(randf_range(-2.5, 2.5), randf_range(-1.0, 1.5), randf_range(-2.5, 2.5))
	Fx.tracer(get_parent(), from, end, Color(1.0, 0.35, 0.3))
	Fx.spark(get_parent(), from, Color(1.0, 0.8, 0.3))
	if hit:
		target.take_damage(DMG, self)


func take_damage(amount: float, source: Node = null) -> bool:
	if not alive:
		return false
	health -= amount
	_visual.scale = Vector3.ONE * 1.15
	if source is Player:
		_last_known = source.global_position
		_memory = 6.0
	if health <= 0.0:
		_die()
		return true
	return false


func _die() -> void:
	alive = false
	collision_layer = 0
	collision_mask = 0
	remove_from_group("enemies")
	died.emit(self)
	var tw := create_tween()
	tw.tween_property(_visual, "rotation:x", -PI / 2.0, 0.35)
	tw.parallel().tween_property(_visual, "position:y", 0.3, 0.35)
	tw.tween_interval(3.0)
	tw.tween_callback(queue_free)
