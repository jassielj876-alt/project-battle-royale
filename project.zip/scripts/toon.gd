class_name Toon
extends RefCounted
## Utilidades para construir geometría caricaturesca por código
## (sin tener que diseñar nada a mano en el editor).

static var _shader: Shader
static var _outline_shader: Shader
static var _cache := {}


static func mat(color: Color, outline: bool = false) -> ShaderMaterial:
	var key := "%s_%s" % [color.to_html(), outline]
	if _cache.has(key):
		return _cache[key]
	if _shader == null:
		_shader = load("res://shaders/toon.gdshader") as Shader
	var m := ShaderMaterial.new()
	m.shader = _shader
	m.set_shader_parameter("base_color", color)
	if outline:
		if _outline_shader == null:
			_outline_shader = load("res://shaders/outline.gdshader") as Shader
		var o := ShaderMaterial.new()
		o.shader = _outline_shader
		m.next_pass = o
	_cache[key] = m
	return m


static func mesh(parent: Node, m: Mesh, pos: Vector3, color: Color, outline: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.position = pos
	mi.material_override = mat(color, outline)
	parent.add_child(mi)
	return mi


## Caja. Si solid = true, tiene colisión (StaticBody3D).
static func box(parent: Node, size: Vector3, pos: Vector3, color: Color, solid: bool = true, rot_y: float = 0.0, outline: bool = false) -> Node3D:
	var bm := BoxMesh.new()
	bm.size = size
	var root: Node3D
	if solid:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		sb.add_child(cs)
		root = sb
	else:
		root = Node3D.new()
	root.position = pos
	root.rotation.y = rot_y
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat(color, outline)
	root.add_child(mi)
	parent.add_child(root)
	return root


## Cilindro. rot_x permite acostarlo (por ejemplo, cañones de tanque).
static func cyl(parent: Node, radius: float, height: float, pos: Vector3, color: Color, solid: bool = true, rot_x: float = 0.0, outline: bool = false) -> Node3D:
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 12
	cm.rings = 1
	var root: Node3D
	if solid:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var sh := CylinderShape3D.new()
		sh.radius = radius
		sh.height = height
		cs.shape = sh
		sb.add_child(cs)
		root = sb
	else:
		root = Node3D.new()
	root.position = pos
	root.rotation.x = rot_x
	var mi := MeshInstance3D.new()
	mi.mesh = cm
	mi.material_override = mat(color, outline)
	root.add_child(mi)
	parent.add_child(root)
	return root


## Solo colisión (sin malla).
static func solid_box(parent: Node, size: Vector3, pos: Vector3) -> StaticBody3D:
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	sb.add_child(cs)
	sb.position = pos
	parent.add_child(sb)
	return sb
