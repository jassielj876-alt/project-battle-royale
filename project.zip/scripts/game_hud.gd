class_name GameHUD
extends Control
## HUD dibujado por código: mira, vida, munición, vivos, bajas, zona y pantalla final.

signal restart_requested

var health := 100.0
var ammo := 30
var reserve := 120
var reloading := false
var alive_count := 0
var kills := 0
var zone_text := ""
var zone_angle := 0.0
var zone_dist := 0.0
var in_zone := true

var _dmg_t := 0.0
var _hit_t := 0.0
var _msg := ""
var _msg_t := 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func flash_damage() -> void:
	_dmg_t = 0.6


func flash_hit(killed: bool) -> void:
	_hit_t = 0.25
	if killed:
		show_message("¡ELIMINADO!", 1.5)


func show_message(text: String, secs: float = 3.0) -> void:
	_msg = text
	_msg_t = secs


func _process(delta: float) -> void:
	_dmg_t = maxf(_dmg_t - delta, 0.0)
	_hit_t = maxf(_hit_t - delta, 0.0)
	_msg_t = maxf(_msg_t - delta, 0.0)
	queue_redraw()


func _txt(t: String, p: Vector2, fs: int, col: Color = Color.WHITE, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:
	var font := ThemeDB.fallback_font
	draw_string_outline(font, p, t, align, width, fs, 6, Color(0, 0, 0, 0.85))
	draw_string(font, p, t, align, width, fs, col)


func _draw() -> void:
	var w := size.x
	var h := size.y
	var c := size / 2.0

	if _dmg_t > 0.0:
		draw_rect(Rect2(Vector2.ZERO, size), Color(1, 0, 0, clampf(_dmg_t, 0.0, 1.0) * 0.35))
	if not in_zone:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.7, 0.1, 0.9, 0.12))

	# Mira
	var cc := Color(1.0, 0.25, 0.2) if _hit_t > 0.0 else Color.WHITE
	var gap := 10.0
	var ln := 14.0
	draw_line(c + Vector2(-gap - ln, 0), c + Vector2(-gap, 0), cc, 3.0)
	draw_line(c + Vector2(gap, 0), c + Vector2(gap + ln, 0), cc, 3.0)
	draw_line(c + Vector2(0, -gap - ln), c + Vector2(0, -gap), cc, 3.0)
	draw_line(c + Vector2(0, gap), c + Vector2(0, gap + ln), cc, 3.0)
	draw_circle(c, 2.0, cc)

	# Vida
	var bw := 360.0
	var bx := c.x - bw / 2.0
	var by := h - 52.0
	draw_rect(Rect2(bx - 3.0, by - 3.0, bw + 6.0, 30.0), Color(0, 0, 0, 0.55))
	var hp := clampf(health / 100.0, 0.0, 1.0)
	var hc := Color(0.35, 0.9, 0.35).lerp(Color(0.95, 0.25, 0.2), 1.0 - hp)
	draw_rect(Rect2(bx, by, bw * hp, 24.0), hc)
	_txt("%d" % int(ceil(health)), Vector2(c.x - 40.0, by + 21.0), 22, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 80.0)

	# Munición
	var at := "RECARGANDO..." if reloading else "%d / %d" % [ammo, reserve]
	_txt(at, Vector2(c.x - 140.0, by - 14.0), 34, Color(1.0, 0.9, 0.4), HORIZONTAL_ALIGNMENT_CENTER, 280.0)

	# Vivos y bajas
	_txt("VIVOS: %d" % alive_count, Vector2(24.0, 50.0), 36)
	_txt("BAJAS: %d" % kills, Vector2(24.0, 92.0), 30, Color(1.0, 0.85, 0.4))

	# Zona
	_txt(zone_text, Vector2(w - 24.0 - 340.0, 50.0), 30, Color(1.0, 0.6, 0.7), HORIZONTAL_ALIGNMENT_RIGHT, 340.0)
	var ac := Vector2(w - 70.0, 120.0)
	draw_circle(ac, 40.0, Color(0, 0, 0, 0.45))
	var pts := PackedVector2Array([Vector2(0, -30), Vector2(20, 22), Vector2(0, 10), Vector2(-20, 22)])
	for i in pts.size():
		pts[i] = ac + pts[i].rotated(zone_angle) * 0.9
	draw_colored_polygon(pts, Color(0.4, 0.9, 1.0))
	_txt("%d m" % int(zone_dist), Vector2(w - 24.0 - 340.0, 185.0), 26, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT, 340.0)

	if not in_zone:
		_txt("¡FUERA DE LA ZONA!", Vector2(c.x - 250.0, 230.0), 40, Color(1.0, 0.3, 0.9), HORIZONTAL_ALIGNMENT_CENTER, 500.0)

	if _msg_t > 0.0:
		_txt(_msg, Vector2(c.x - 300.0, 150.0), 44, Color(1.0, 0.95, 0.5), HORIZONTAL_ALIGNMENT_CENTER, 600.0)


func show_end(title: String, subtitle: String, col: Color) -> void:
	var overlay := ColorRect.new()
	overlay.color = Color(0, 0, 0, 0.62)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(overlay)

	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	box.grow_vertical = Control.GROW_DIRECTION_BOTH
	box.add_theme_constant_override("separation", 24)
	overlay.add_child(box)

	var l1 := Label.new()
	l1.text = title
	l1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l1.add_theme_font_size_override("font_size", 84)
	l1.add_theme_color_override("font_color", col)
	l1.add_theme_color_override("font_outline_color", Color.BLACK)
	l1.add_theme_constant_override("outline_size", 12)
	box.add_child(l1)

	var l2 := Label.new()
	l2.text = subtitle
	l2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l2.add_theme_font_size_override("font_size", 36)
	box.add_child(l2)

	var btn := Button.new()
	btn.text = "JUGAR DE NUEVO"
	btn.custom_minimum_size = Vector2(460, 100)
	btn.add_theme_font_size_override("font_size", 40)
	btn.pressed.connect(func(): restart_requested.emit())
	box.add_child(btn)
