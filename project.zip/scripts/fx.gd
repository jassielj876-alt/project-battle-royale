class_name Fx
extends RefCounted
## Efectos visuales simples: trazadoras de bala y chispas de impacto.

static var _cache := {}


static func _unshaded(color: Color) -> StandardMaterial3D:
	var key := color.to_html()
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = color
	_cache[key] = m
	return m


static func tracer(parent: Node, from: Vector3, to: Vector3, color: Color = Color(1.0, 0.9, 0.4)) -> void:
	var length := from.distance_to(to)
	if length < 0.5 or parent == null or not parent.is_inside_tree():
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.04, 0.04, length)
	mi.mesh = bm
	mi.material_override = _unshaded(color)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	mi.global_position = (from + to) * 0.5
	var dir := (to - from).normalized()
	var up := Vector3.UP
	if absf(dir.dot(up)) > 0.98:
		up = Vector3.RIGHT
	mi.look_at(to, up)
	parent.get_tree().create_timer(0.06).timeout.connect(mi.queue_free)


static func spark(parent: Node, pos: Vector3, color: Color = Color(1.0, 0.85, 0.5)) -> void:
	if parent == null or not parent.is_inside_tree():
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.2, 0.2, 0.2)
	mi.mesh = bm
	mi.material_override = _unshaded(color)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	mi.global_position = pos
	mi.rotation = Vector3(randf() * TAU, randf() * TAU, 0.0)
	parent.get_tree().create_timer(0.1).timeout.connect(mi.queue_free)
