class_name GameWorld
extends Node3D
## Mapa de desierto militar generado 100% por código:
## base central, 4 puestos avanzados, torres, tanques, contenedores,
## cactus, rocas, barriles, cajas y loot.

const HALF := 120.0

var rng := RandomNumberGenerator.new()
var _obstacles: Array[Vector3] = [] # x, z, radio


func build() -> void:
	rng.seed = 20260
	_ground()
	_border()
	_dunes()
	_central_base()
	_outpost(Vector3(-72, 0, -62), 0)
	_outpost(Vector3(74, 0, -58), 1)
	_outpost(Vector3(-68, 0, 70), 2)
	_outpost(Vector3(72, 0, 66), 3)
	_scatter()
	_scatter_loot(24)


# ------------------------------------------------------------------ utilidades

func _reg(p: Vector3, r: float) -> void:
	_obstacles.append(Vector3(p.x, p.z, r))


func _is_free(p: Vector3, margin: float) -> bool:
	for o in _obstacles:
		if Vector2(p.x - o.x, p.z - o.y).length() < o.z + margin:
			return false
	return true


## Punto aleatorio libre (para aparecer jugador/enemigos). Usa el azar global.
func random_free_point(min_r: float = 0.0, max_r: float = 105.0) -> Vector3:
	for i in 80:
		var a := randf() * TAU
		var r := randf_range(min_r, max_r)
		var p := Vector3(cos(a) * r, 0.0, sin(a) * r)
		if _is_free(p, 2.5):
			return p
	return Vector3(max_r, 0.0, 0.0)


func _group(pos: Vector3, rot_y: float) -> Node3D:
	var g := Node3D.new()
	g.position = pos
	g.rotation.y = rot_y
	add_child(g)
	return g


func _off(c: Vector3, v: Vector3, yaw: float) -> Vector3:
	return c + v.rotated(Vector3.UP, yaw)


func _loot(pos: Vector3, kind: String = "") -> void:
	var p := Pickup.new()
	if kind == "":
		kind = "health" if rng.randf() < 0.45 else "ammo"
	p.kind = kind
	p.position = pos
	add_child(p)


# ------------------------------------------------------------------ terreno

func _ground() -> void:
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(600, 2, 600)
	cs.shape = bs
	cs.position = Vector3(0, -1, 0)
	sb.add_child(cs)
	add_child(sb)

	var pm := PlaneMesh.new()
	pm.size = Vector2(600, 600)
	Toon.mesh(self, pm, Vector3.ZERO, Color("d4a455"))

	# Caminos de asfalto en cruz
	Toon.box(self, Vector3(HALF * 2.0, 0.05, 8.0), Vector3(0, 0.03, 0), Color("77706a"), false)
	Toon.box(self, Vector3(8.0, 0.05, HALF * 2.0), Vector3(0, 0.03, 0), Color("77706a"), false)


func _border() -> void:
	var d := HALF + 4.0
	var wall_col := Color("b9b2a3")
	var specs := [
		[Vector3(0, 0, d), Vector3(2.0 * d, 4.0, 1.0)],
		[Vector3(0, 0, -d), Vector3(2.0 * d, 4.0, 1.0)],
		[Vector3(d, 0, 0), Vector3(1.0, 4.0, 2.0 * d)],
		[Vector3(-d, 0, 0), Vector3(1.0, 4.0, 2.0 * d)],
	]
	for s in specs:
		var p: Vector3 = s[0]
		var sz: Vector3 = s[1]
		Toon.box(self, sz, p + Vector3(0, sz.y / 2.0, 0), wall_col, false)
		# Colisión alta e invisible para que nadie salte el muro
		Toon.solid_box(self, Vector3(sz.x, 30.0, sz.z), p + Vector3(0, 15.0, 0))


func _dunes() -> void:
	for i in 34:
		var a := rng.randf() * TAU
		var r := rng.randf_range(150.0, 210.0)
		var sm := SphereMesh.new()
		sm.radius = 1.0
		sm.height = 2.0
		sm.radial_segments = 16
		sm.rings = 8
		var col := Color("c99a4c").lerp(Color("deb96e"), rng.randf())
		var mi := Toon.mesh(self, sm, Vector3(cos(a) * r, -1.0, sin(a) * r), col)
		mi.scale = Vector3(rng.randf_range(25.0, 50.0), rng.randf_range(8.0, 18.0), rng.randf_range(25.0, 50.0))


# ------------------------------------------------------------------ estructuras

## Edificio hueco con puerta en el lado +Z local.
func _building(pos: Vector3, size: Vector3, color: Color, rot_y: float = 0.0, door_w: float = 3.0, door_h: float = 2.8) -> void:
	var g := _group(pos, rot_y)
	var t := 0.4
	var w := size.x
	var h := size.y
	var d := size.z
	Toon.box(g, Vector3(w, h, t), Vector3(0, h / 2.0, -d / 2.0 + t / 2.0), color)
	Toon.box(g, Vector3(t, h, d), Vector3(-w / 2.0 + t / 2.0, h / 2.0, 0), color)
	Toon.box(g, Vector3(t, h, d), Vector3(w / 2.0 - t / 2.0, h / 2.0, 0), color)
	var seg := (w - door_w) / 2.0
	Toon.box(g, Vector3(seg, h, t), Vector3(-w / 2.0 + seg / 2.0, h / 2.0, d / 2.0 - t / 2.0), color)
	Toon.box(g, Vector3(seg, h, t), Vector3(w / 2.0 - seg / 2.0, h / 2.0, d / 2.0 - t / 2.0), color)
	var lintel_h := h - door_h
	Toon.box(g, Vector3(door_w, lintel_h, t), Vector3(0, door_h + lintel_h / 2.0, d / 2.0 - t / 2.0), color)
	Toon.box(g, Vector3(w + 0.8, 0.4, d + 0.8), Vector3(0, h + 0.2, 0), color.darkened(0.25))
	# Franja decorativa
	Toon.box(g, Vector3(w + 0.05, 0.35, d + 0.05), Vector3(0, 0.9, 0), color.darkened(0.12), false)


func _container(pos: Vector3, rot_y: float, color: Color) -> void:
	var g := _group(pos, rot_y)
	Toon.box(g, Vector3(6.0, 2.6, 2.4), Vector3(0, 1.3, 0), color, true, 0.0, true)
	Toon.box(g, Vector3(6.05, 0.25, 2.45), Vector3(0, 2.0, 0), color.darkened(0.25), false)
	Toon.box(g, Vector3(6.05, 0.25, 2.45), Vector3(0, 0.6, 0), color.darkened(0.25), false)
	_reg(pos, 4.0)


func _tower(pos: Vector3) -> void:
	var g := _group(pos, 0.0)
	var leg := Color("5a5f4a")
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			Toon.box(g, Vector3(0.5, 9.0, 0.5), Vector3(sx * 1.6, 4.5, sz * 1.6), leg)
	Toon.box(g, Vector3(4.6, 0.4, 4.6), Vector3(0, 9.0, 0), Color("6e7358"), false)
	Toon.box(g, Vector3(4.2, 2.2, 4.2), Vector3(0, 10.3, 0), Color("7d8465"))
	Toon.box(g, Vector3(5.2, 0.4, 5.2), Vector3(0, 11.6, 0), Color("4f533f"), false)
	Toon.box(g, Vector3(4.3, 0.5, 0.1), Vector3(0, 10.5, 2.15), Color("1f2a30"), false)
	_reg(pos, 4.0)


func _sandbags(pos: Vector3, rot_y: float, count: int = 5) -> void:
	var g := _group(pos, rot_y)
	var bag := Color("cdb67f")
	for i in count:
		var x := (i - (count - 1) / 2.0) * 1.3
		Toon.box(g, Vector3(1.3, 0.6, 0.8), Vector3(x, 0.3, 0), bag, true, 0.0, false)
	for i in count - 1:
		var x2 := (i - (count - 1) / 2.0 + 0.5) * 1.3
		Toon.box(g, Vector3(1.3, 0.6, 0.8), Vector3(x2, 0.9, 0), bag.darkened(0.08))
	_reg(pos, count * 0.7)


func _tank(pos: Vector3, rot_y: float) -> void:
	var g := _group(pos, rot_y)
	Toon.box(g, Vector3(3.0, 1.2, 6.0), Vector3(0, 1.0, 0), Color("6f7b4f"), true, 0.0, true)
	Toon.box(g, Vector3(0.9, 1.0, 6.4), Vector3(-1.95, 0.6, 0), Color("3d3d36"), false)
	Toon.box(g, Vector3(0.9, 1.0, 6.4), Vector3(1.95, 0.6, 0), Color("3d3d36"), false)
	Toon.box(g, Vector3(2.2, 0.9, 2.6), Vector3(0, 2.05, 0.3), Color("7c8a58"), true, 0.0, true)
	Toon.cyl(g, 0.18, 4.0, Vector3(0, 2.15, -2.0), Color("55603c"), false, PI / 2.0)
	_reg(pos, 5.0)


func _tent(pos: Vector3, rot_y: float) -> void:
	var g := _group(pos, rot_y)
	var pm := PrismMesh.new()
	pm.size = Vector3(4.0, 2.6, 5.0)
	Toon.mesh(g, pm, Vector3(0, 1.3, 0), Color("8c9a5b"), true)
	Toon.solid_box(g, Vector3(3.0, 2.0, 5.0), Vector3(0, 1.0, 0))
	_reg(pos, 3.5)


func _cactus(pos: Vector3) -> void:
	var g := _group(pos, rng.randf() * TAU)
	var green := Color("4fa05a")
	var h := rng.randf_range(2.0, 4.0)
	Toon.cyl(g, 0.35, h, Vector3(0, h / 2.0, 0), green, true, 0.0, false)
	Toon.box(g, Vector3(0.8, 0.4, 0.4), Vector3(0.5, h * 0.5, 0), green, false)
	Toon.cyl(g, 0.2, 1.1, Vector3(0.85, h * 0.5 + 0.5, 0), green, false)
	Toon.box(g, Vector3(0.8, 0.4, 0.4), Vector3(-0.5, h * 0.35, 0), green, false)
	Toon.cyl(g, 0.2, 0.9, Vector3(-0.85, h * 0.35 + 0.4, 0), green, false)


func _rock(pos: Vector3) -> void:
	var s := rng.randf_range(1.4, 3.4)
	var col := Color("b39a74").lerp(Color("8e7b5e"), rng.randf())
	Toon.box(self, Vector3(s, s * 0.8, s * 0.9), pos + Vector3(0, s * 0.4, 0), col, true, rng.randf() * TAU, true)


func _barrel(pos: Vector3) -> void:
	var cols := [Color("c23b2e"), Color("d9a21b"), Color("4a6b3a")]
	var col: Color = cols[rng.randi() % cols.size()]
	Toon.cyl(self, 0.5, 1.2, pos + Vector3(0, 0.6, 0), col, true, 0.0, true)
	Toon.cyl(self, 0.52, 0.12, pos + Vector3(0, 0.6, 0), col.darkened(0.3), false)


func _crate_stack(pos: Vector3) -> void:
	var wood := Color("b0803f")
	var yaw := rng.randf() * TAU
	Toon.box(self, Vector3(1.4, 1.4, 1.4), pos + Vector3(0, 0.7, 0), wood, true, yaw, true)
	Toon.box(self, Vector3(1.0, 1.0, 1.0), pos + Vector3(0.1, 1.9, 0), wood.lightened(0.1), true, yaw + 0.5, true)


# ------------------------------------------------------------------ zonas

func _central_base() -> void:
	_building(Vector3(0, 0, -26), Vector3(24, 8, 14), Color("c9b48a"), 0.0, 9.0, 5.5)
	_reg(Vector3(0, 0, -26), 16.0)
	_loot(Vector3(-4, 0, -26), "ammo")
	_loot(Vector3(4, 0, -26), "health")

	_building(Vector3(-30, 0, 14), Vector3(14, 4, 8), Color("9aa070"), PI / 2.0)
	_reg(Vector3(-30, 0, 14), 9.0)
	_loot(Vector3(-30, 0, 14), "ammo")
	_building(Vector3(30, 0, 14), Vector3(14, 4, 8), Color("9aa070"), -PI / 2.0)
	_reg(Vector3(30, 0, 14), 9.0)
	_loot(Vector3(30, 0, 14), "health")

	_tower(Vector3(-20, 0, -8))
	_tower(Vector3(20, 0, 9))

	_container(Vector3(16, 0, -14), 0.3, Color("b5533c"))
	_container(Vector3(22, 0, -12), -0.2, Color("3c6fb5"))
	_container(Vector3(-16, 0, 20), 0.5, Color("c9a23a"))

	_tank(Vector3(9, 0, 18), 0.6)
	_tank(Vector3(-10, 0, 26), -0.4)

	_sandbags(Vector3(0, 0, 10), 0.0, 6)
	_sandbags(Vector3(-12, 0, -4), 1.2, 5)
	_sandbags(Vector3(12, 0, 2), -1.0, 5)
	_loot(Vector3(0, 0, 7), "ammo")
	_loot(Vector3(-12, 0, 0), "health")


func _outpost(c: Vector3, k: int) -> void:
	var toward := (-c).normalized()
	var yaw := atan2(toward.x, toward.z) # la puerta mira al centro del mapa
	var wall := Color("d2b27a") if k % 2 == 0 else Color("a7a37a")
	_building(c, Vector3(9, 3.8, 7), wall, yaw)
	_reg(c, 7.0)
	_loot(c, "ammo")
	_loot(_off(c, Vector3(2, 0, 1), yaw), "health")

	_tower(_off(c, Vector3(-13, 0, 7), yaw))
	var cont_cols := [Color("b5533c"), Color("3c6fb5"), Color("c9a23a"), Color("5a8f4a")]
	_container(_off(c, Vector3(12, 0, -2), yaw), yaw + 0.4, cont_cols[k % 4])
	_container(_off(c, Vector3(14, 0, 5), yaw), yaw - 0.3, cont_cols[(k + 1) % 4])
	_tent(_off(c, Vector3(-10, 0, -8), yaw), yaw + 0.3)
	_tent(_off(c, Vector3(-4, 0, -12), yaw), yaw - 0.2)
	_sandbags(_off(c, Vector3(0, 0, 10), yaw), yaw, 5)
	_loot(_off(c, Vector3(-9, 0, -4), yaw))
	if k % 2 == 1:
		_tank(_off(c, Vector3(0, 0, -16), yaw), yaw + 1.0)


func _scatter() -> void:
	var placed := 0
	var tries := 0
	while placed < 130 and tries < 1500:
		tries += 1
		var p := Vector3(rng.randf_range(-HALF + 6.0, HALF - 6.0), 0.0, rng.randf_range(-HALF + 6.0, HALF - 6.0))
		if absf(p.x) < 5.5 or absf(p.z) < 5.5:
			continue # dejar los caminos libres
		if not _is_free(p, 2.0):
			continue
		var t := rng.randi() % 10
		if t < 4:
			_cactus(p)
		elif t < 7:
			_rock(p)
		elif t < 9:
			_barrel(p)
		else:
			_crate_stack(p)
		_reg(p, 2.0)
		placed += 1


func _scatter_loot(n: int) -> void:
	var placed := 0
	var tries := 0
	while placed < n and tries < 600:
		tries += 1
		var p := Vector3(rng.randf_range(-HALF + 8.0, HALF - 8.0), 0.0, rng.randf_range(-HALF + 8.0, HALF - 8.0))
		if not _is_free(p, 1.5):
			continue
		_loot(p)
		_reg(p, 1.0)
		placed += 1
